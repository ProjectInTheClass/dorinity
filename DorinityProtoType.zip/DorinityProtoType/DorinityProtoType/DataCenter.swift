//
//  DataCenter.swift
//  DorinityProtoType
//
//  Created by Jisoo Kim on 2018. 1. 25..
//  Copyright © 2018년 Jisoo Kim. All rights reserved.
//

import Foundation

let dataCenter:DataCenter = DataCenter()

class DataCenter{
    var figures:[Figure] = []
    
    init(){
        let drawLine = Act(name: "선 긋기")
        let selectColor = Act(name: "펜 색깔 정하기")
    
        let rectangle = Figure(name : "직육면체")
        let triangle = Figure(name : "사면체")
        rectangle.acts = [drawLine, selectColor]
        triangle.acts = [drawLine]
        
        figures += [rectangle, triangle]
    }
}

class Figure{
    let name:String
    var acts:[Act]?
    
    init(name:String){
        self.name = name
    }
}

class Act{
    let name:String
    
    init(name:String){
        self.name = name
    }
}
