/*Copyright (c) 2016, Andrew Walz.
 
 Redistribution and use in source and binary forms, with or without modification,are permitted provided that the following conditions are met:
 
 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 
 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the
 documentation and/or other materials provided with the distribution.
 
 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS
 BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
 GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. */

import UIKit
import GLKit


class ViewController: UIViewController, SwiftyDrawViewDelegate {
    @IBOutlet var entireView: UIView!
    
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var drawView2: UIView! //이걸 도면 구역만큼 만들어야하지않나?
    @IBOutlet weak var testView: UIImageView!
    var selectedIdx : Int?
    var drawView : SwiftyDrawView! //class 이것도 도면 구역만큼 있어야함. 아니면 좌표로 그리기제한
    var redButton : ColorButton!
    var greenButton : ColorButton!
    var blueButton : ColorButton!
    var orangeButton : ColorButton!
    var purpleButton : ColorButton!
    var yellowButton : ColorButton!
    var blackButton : ColorButton!
    var brownButton : ColorButton!
    var whiteButton : ColorButton!
    var undoButton : UIButton!
    var deleteButton : UIButton!
    var lineWidthSlider : UISlider!
    var opacitySlider : UISlider!
    let openGlViewController = ViewControllerGL()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        //drawView = SwiftyDrawView(frame: self.view.frame)
        
        if let selectedIdx = selectedIdx {
            switch selectedIdx {
            case 0 :
                print("0")
            case 1 :
                print("1")
            case 2:
                print("2")
            case 3:
                print("3")
            default:
                print("default")
            }
        }
        
        drawView = SwiftyDrawView(frame: drawView2.frame)
        drawView.delegate = self
        
        let _ = openGlViewController.view
        openGlViewController.glkView.frame = containerView.bounds
        containerView.addSubview(openGlViewController.glkView)
        self.view.addSubview(drawView)
        addButtons()
        addSliders()
        openGlViewController.setupGLcontext()
        openGlViewController.setupGLupdater()
        openGlViewController.setupScene()
    }

    func addButtons() {
        blackButton = ColorButton(frame: CGRect(x: self.view.frame.width - 200, y: self.view.frame.height - 120, width: 40, height: 40), color: UIColor.black)
        blackButton.addTarget(self, action: #selector(colorButtonPressed(button:)), for: .touchUpInside)
        self.view.addSubview(blackButton)
        
        brownButton = ColorButton(frame: CGRect(x: self.view.frame.width - 200, y: self.view.frame.height - 170, width: 40, height: 40), color: UIColor.brown)
        brownButton.addTarget(self, action: #selector(colorButtonPressed(button:)), for: .touchUpInside)
        self.view.addSubview(brownButton)
        
        whiteButton = ColorButton(frame: CGRect(x: self.view.frame.width - 200, y: self.view.frame.height - 220, width: 40, height: 40), color: UIColor.white)
        whiteButton.addTarget(self, action: #selector(colorButtonPressed(button:)), for: .touchUpInside)
        self.view.addSubview(whiteButton)
        
        
        redButton = ColorButton(frame: CGRect(x: self.view.frame.width - 150, y: self.view.frame.height - 120, width: 40, height: 40), color: UIColor.red)
        redButton.addTarget(self, action: #selector(colorButtonPressed(button:)), for: .touchUpInside)
        self.view.addSubview(redButton)
        
        greenButton = ColorButton(frame: CGRect(x: self.view.frame.width - 150, y: self.view.frame.height - 170, width: 40, height: 40), color: UIColor.green)
        greenButton.addTarget(self, action: #selector(colorButtonPressed(button:)), for: .touchUpInside)
        self.view.addSubview(greenButton)
        
        blueButton = ColorButton(frame: CGRect(x: self.view.frame.width - 150, y: self.view.frame.height - 220, width: 40, height: 40), color: UIColor.blue)
        blueButton.addTarget(self, action: #selector(colorButtonPressed(button:)), for: .touchUpInside)
        self.view.addSubview(blueButton)
        
        orangeButton = ColorButton(frame: CGRect(x: self.view.frame.width - 100, y: self.view.frame.height - 220, width: 40, height: 40), color: UIColor.orange)
        orangeButton.addTarget(self, action: #selector(colorButtonPressed(button:)), for: .touchUpInside)
        self.view.addSubview(orangeButton)
        
        purpleButton = ColorButton(frame: CGRect(x: self.view.frame.width - 100, y: self.view.frame.height - 170, width: 40, height: 40), color: UIColor.purple)
        purpleButton.addTarget(self, action: #selector(colorButtonPressed(button:)), for: .touchUpInside)
        self.view.addSubview(purpleButton)
        
        yellowButton = ColorButton(frame: CGRect(x: self.view.frame.width - 100, y: self.view.frame.height - 120, width: 40, height: 40), color: UIColor.yellow)
        yellowButton.addTarget(self, action: #selector(colorButtonPressed(button:)), for: .touchUpInside)
        self.view.addSubview(yellowButton)
        
        undoButton = UIButton(frame: CGRect(x: 80, y: 30, width: 60, height: 30))
        undoButton.setTitleColor(UIColor.black, for: UIControlState())
        undoButton.setTitle("undo", for: UIControlState())
        undoButton.addTarget(self, action: #selector(undo), for: .touchUpInside)
        self.view.addSubview(undoButton)
        
        deleteButton = UIButton(frame: CGRect(x: 10, y: 30, width: 60, height: 30))
        deleteButton.setTitleColor(UIColor.black, for: UIControlState())
        deleteButton.setTitle("back", for: UIControlState())
        deleteButton.addTarget(self, action: #selector(back), for: .touchUpInside)
        self.view.addSubview(deleteButton)
    }
    
    func addSliders() {
        lineWidthSlider = UISlider(frame: CGRect(x: self.view.frame.width - 200, y: self.view.frame.height - 50, width: 150, height: 40))
        lineWidthSlider.minimumValue = 1.0
        lineWidthSlider.maximumValue = 30.0
        lineWidthSlider.setValue(10.0, animated: false)
        lineWidthSlider.isContinuous = true
        lineWidthSlider.addTarget(self, action: #selector(lineWidthSliderValueDidChange(sender:)), for: .valueChanged)
        self.view.addSubview(lineWidthSlider)
        
        opacitySlider = UISlider(frame: CGRect(x: self.view.frame.width - 200, y: self.view.frame.height - 80, width: 150, height: 40))
        opacitySlider.minimumValue = 0.001
        opacitySlider.maximumValue = 1.0
        opacitySlider.setValue(1.0, animated: false)
        opacitySlider.isContinuous = true
        opacitySlider.addTarget(self, action: #selector(lineOpacitySliderValueDidChange(sender:)), for: .valueChanged)
        self.view.addSubview(opacitySlider)
    }
    
    func colorButtonPressed(button: ColorButton) {
        drawView.lineColor = button.color
    }
    
    func undo() { //addTarget으로 추가됨.
        drawView.removeLastLine()
    }
    
    func back() { // 실제로 back이라고 적힌 곳. 수정 전 deleteDrawing임. selector부분도 바꿨음.
        //drawView.clearCanvas()
        self.dismiss(animated: true, completion: nil)
    }
    
    func lineWidthSliderValueDidChange(sender:UISlider!) {
        drawView.lineWidth = CGFloat(sender.value)
    }
    
    func lineOpacitySliderValueDidChange(sender:UISlider!) {
        drawView.lineOpacity = CGFloat(sender.value)
    }
    
    func SwiftyDrawDidBeginDrawing(view: SwiftyDrawView) {
        //print("Did begin drawing")
        
        /*
        UIView.animate(withDuration: 0.5, animations: {
            self.redButton.alpha = 0.0
            self.blueButton.alpha = 0.0
            self.greenButton.alpha = 0.0
            self.orangeButton.alpha = 0.0
            self.purpleButton.alpha = 0.0
            self.yellowButton.alpha = 0.0
            self.undoButton.alpha = 0.0
            self.deleteButton.alpha = 0.0
            self.lineWidthSlider.alpha = 0.0
            self.opacitySlider.alpha = 0.0
        })*/
    }
    
    func SwiftyDrawIsDrawing(view: SwiftyDrawView) {
        //print("Is Drawing")
    }
    
    func SwiftyDrawDidFinishDrawing(view: SwiftyDrawView) {
        //print("Did finish drawing")
        var testImage:UIImageView
        testImage = takeScreenshot(view: drawView)
        print(testImage.frame)
        
        if let paramImage = testImage.image { // crop한 이미지
            let image_r = crop(image: paramImage, cropRect: CGRect(x: 92.0, y: 254.0, width: 116, height: 116))
            testView.image = image_r
        }
     //   let image_r = crop(image: testImage.image?, cropRect: )
        if let data = UIImagePNGRepresentation(testImage.image!){
            let path: String = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first!
            let url = URL(fileURLWithPath: path).appendingPathComponent("test.png")
            try? data.write(to: url)
        }
        /*
        UIView.animate(withDuration: 0.5, animations: {
            self.redButton.alpha = 1.0
            self.blueButton.alpha = 1.0
            self.greenButton.alpha = 1.0
            self.orangeButton.alpha = 1.0
            self.purpleButton.alpha = 1.0
            self.yellowButton.alpha = 1.0
            self.undoButton.alpha = 1.0
            self.deleteButton.alpha = 1.0
            self.lineWidthSlider.alpha = 1.0
            self.opacitySlider.alpha = 1.0
        })*/
    }
    
    func SwiftyDrawDidCancelDrawing(view: SwiftyDrawView) {
        //print("Did cancel")
    }
    func takeScreenshot(view: UIView) -> UIImageView {
        UIGraphicsBeginImageContext(view.frame.size)
        //print(view.frame.size)
        view.layer.render(in: UIGraphicsGetCurrentContext()!)
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        UIImageWriteToSavedPhotosAlbum(image!, nil, nil, nil)
       
        return UIImageView(image: image)
    }
    
    func crop(image:UIImage, cropRect:CGRect) -> UIImage? {
        UIGraphicsBeginImageContextWithOptions(cropRect.size, false, image.scale)
        let origin = CGPoint(x: cropRect.origin.x * CGFloat(-1), y: cropRect.origin.y * CGFloat(-1))
        image.draw(at: origin)
        let result = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext();
        
        return result
    }
    
}
