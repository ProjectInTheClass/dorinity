//
//  DataCenter.swift
//  scrollView
//
//  Created by Jisoo Kim on 2018. 1. 31..
//  Copyright © 2018년 Jisoo Kim. All rights reserved.
//

import Foundation

var dataCenter:DataCenter = DataCenter()

class DataCenter{
    var selectedCase:Int?
}
