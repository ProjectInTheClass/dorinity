//
//  ImageCollectionViewCell.swift
//  scrollView
//
//  Created by Jisoo Kim on 2018. 1. 30..
//  Copyright © 2018년 Jisoo Kim. All rights reserved.
//

import UIKit

class ImageCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imgImage: UIImageView!
    
    /*
    // Set the indexPath of the selected item as the sender for the segue
    func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath) {
        performSegueWithIdentifier("pastTripCollectionToSavedLocationSegue", sender: indexPath)
    }
    */
}
