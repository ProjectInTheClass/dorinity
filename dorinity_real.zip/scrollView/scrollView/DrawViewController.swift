//
//  DrawViewController.swift
//  scrollView
//
//  Created by Jisoo Kim on 2018. 1. 30..
//  Copyright © 2018년 Jisoo Kim. All rights reserved.
//

import UIKit

class DrawViewController: UIViewController {
    @IBOutlet weak var imageLeft: UIImageView!
    @IBOutlet weak var imageTop: UIImageView!
    @IBOutlet weak var imageBottom: UIImageView!
    
    var selectedIdx : Int?

    @IBAction func cancel(_ sender: Any) {
        print("cancel")
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func undo(_ sender: Any) {
        print("undo")
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        if let selectedIdx = selectedIdx {
            switch selectedIdx {
                case 0 :
                imageTop.image = UIImage(named : "menu_1")
                case 1 :
                imageTop.image = UIImage(named : "menu_2")
                case 2:
                if imageTop != nil {
                imageTop.image = UIImage(named : "menu_3")
                }
                case 3:
                imageTop.image = UIImage(named : "menu_4")
                default:
                imageBottom.image = UIImage(named : "5")
            }
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        print("hi")
        
    }

}
