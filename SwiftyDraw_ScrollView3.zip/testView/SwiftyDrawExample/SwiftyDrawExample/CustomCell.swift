//
//  CustomCell.swift
//  SwiftyDrawExample
//
//  Created by Jisoo Kim on 2018. 2. 6..
//  Copyright © 2018년 Walzy. All rights reserved.
//

import UIKit

class CustomCell: UICollectionViewCell {
    
    @IBOutlet weak var myImage: UIImageView!
}
